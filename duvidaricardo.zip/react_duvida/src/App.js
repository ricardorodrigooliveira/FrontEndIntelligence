import React from 'react';
import './App.css';
import Texto from './Texto.js';

function App() {
  return (
    <div className="App">
        <Texto nome="abc"/>
    </div>
  );
}

export default App;
