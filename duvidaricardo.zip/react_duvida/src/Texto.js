import React, {Component} from "react";

class Texto extends Component {
    constructor(props) {
        super(props);
        this.state = {nome: this.props.nome};
        this.nome = React.createRef();
        this.imprimeTexto = this.imprimeTexto.bind(this);
    }

    imprimeTexto() {
        this.setState({nome: this.nome.current.value});
    }

    render() {
        return (
            <div>
                <label class="form-check-label">Digite Seu nome</label>
                <br></br>
                <input type="text" ref={this.nome} class="form-control" placeholder="Digite seu Nome" />
                <input onClick={this.imprimeTexto} type="submit" class="btn btn-primary"
                    value="Adicionar" />
                <ul>
                    {this.state.nome}
                </ul>
            </div>
        )
    }
}

export default Texto;                                                       
